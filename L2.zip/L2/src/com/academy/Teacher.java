package com.academy;

public class Teacher {
    private static long ID;
    public static long counter;
    private String TeacherName;
}
