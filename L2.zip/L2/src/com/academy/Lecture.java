package com.academy;

public class Lecture {
    private static long ID;
    public static long counter;
    private String LectureName;

}
