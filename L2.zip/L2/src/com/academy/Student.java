package com.academy;

public class Student {
    private static long ID;
    public static long counter;
    private String StudentName;
}
