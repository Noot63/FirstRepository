import com.academy.Lecture;
import com.academy.Student;

public class Main {
    public static void main(String[] args){
        Lecture firstLecture = new Lecture();
        Lecture secondLecture = new Lecture();
        Lecture thirdLecture = new Lecture();

        System.out.println(Lecture.counter);
        System.out.println(Student.counter);

    }

            }
