package Service;

public class TeacherService {
    private static long ID;
    public static long counter;
}
