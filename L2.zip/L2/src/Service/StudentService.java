package Service;

public class StudentService {
    private static long ID;
    public static long counter;
}
