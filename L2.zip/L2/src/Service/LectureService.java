package Service;

public class LectureService {
    private static long ID;
    public static long counter;
}
